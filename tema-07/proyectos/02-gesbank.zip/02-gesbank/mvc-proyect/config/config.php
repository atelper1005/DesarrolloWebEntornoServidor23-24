<?php
# Configuración básica aplicación MVC

# Ruta absoluta
define('URL', 'http://localhost/dwes_2324-main/dwes_2324-main/tema-06/proyectos/02-gesbank/mvc-proyect/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>