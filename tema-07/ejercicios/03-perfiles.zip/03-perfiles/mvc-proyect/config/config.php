<?php
# Configuración básica aplicación MVC

# Ruta absoluta

define('URL', 'http://localhost/dwes/tema-07/proyectos/03-perfiles/mvc-proyect/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'fp');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');

?>